package com.edu;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) {

		Configuration conf=new Configuration().configure().addAnnotatedClass(Students.class).addAnnotatedClass(Courses.class);
		ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
		SessionFactory sf=conf.buildSessionFactory(sr);
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();
		
		 
		 Courses c1=new Courses(1, "java", 10000);
		 sess.save(c1);
		 Courses c2=new Courses(2, "python", 14000);
		 sess.save(c2);
		 Courses c3=new Courses(3, "SQL", 15000);
		 sess.save(c3);
		 Courses c4=new Courses(4, "C#", 1000);
		 sess.save(c4);
		 
		
		 Set<Courses>course=new HashSet<Courses>(Arrays.asList(c1,c2,c3));
		 Students s1=new Students(11, "Resh", "8777442434");
		 s1.setCourselist(course);
		 Set<Courses>courses1=new HashSet<Courses>(Arrays.asList(c2,c3,c4));
		Students s2=new Students(12, "Grace", "7724002393");
		 s2.setCourselist(courses1);
		 sess.save(s1);
		
		 sess.save(s2);
		 tran.commit();
		 sess.close();

	}

}
