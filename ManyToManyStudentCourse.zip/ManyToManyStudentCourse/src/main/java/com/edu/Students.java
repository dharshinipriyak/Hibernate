package com.edu;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="StudentsDetails")
public class Students
{
	@Id
	@Column(name="Student_id")
	private int sid;
	
	@Column(name="Student_name",length=30)
	private String sname;
	
	@Column(name="Mobile_Number",length=15)
	private String mobile;
	@ManyToMany
	private Set<Courses>courselist;
	@JoinTable(
			name="HiberStudentCourse",
				joinColumns = {
						@JoinColumn(name="students_id",referencedColumnName = "Student_id")
							},
				inverseJoinColumns = {
									@JoinColumn(name="courses_id",referencedColumnName = "Course_id")
				}
	)
	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Students [sid=" + sid + ", sname=" + sname + ", mobile=" + mobile + ", courselist=" + courselist + "]";
	}
	
	
	public Set<Courses> getCourselist() {
		return courselist;
	}

	public void setCourselist(Set<Courses> courselist) {
		this.courselist = courselist;
	}

	public Students()
	{
		super();
		
	}

	public Students(int sid, String sname, String mobile) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.mobile = mobile;
		
	}
	
}
