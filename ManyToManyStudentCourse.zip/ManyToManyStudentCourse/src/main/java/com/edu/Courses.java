package com.edu;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="CourseDetails")
public class Courses 
{
@Id
@Column(name="Course_id",length=10)
	private int cid;

@Column(name="Course_name",length=30)
	private String cname;
@Column(name="Course_cost")
	private float price;

@ManyToMany(mappedBy = "courselist")
private Set<Students>studentset;
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
@Override
public String toString() {
	return "Courses [cid=" + cid + ", cname=" + cname + ", price=" + price + "]";
}
public Courses() {
	super();
}
public Courses(int cid, String cname, float price) {
	super();
	this.cid = cid;
	this.cname = cname;
	this.price = price;
}
	
}
