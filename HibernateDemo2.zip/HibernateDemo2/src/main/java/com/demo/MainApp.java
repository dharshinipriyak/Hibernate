package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) 
	{
	Employee emp=new Employee();
	//emp.setEmp_id(2);
	emp.setEmp_Name("Uday");
	emp.setEmp_Salary(17109);
	
	Configuration conf=new Configuration().configure().addAnnotatedClass(Employee.class);
	ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
	SessionFactory sf=conf.buildSessionFactory(sr);
	Session ses=sf.openSession();
	//once session open the transaction begins
	Transaction tran=ses.beginTransaction();
	//get record based on id
	//Employee e=(Employee) ses.get(Employee.class,1);
	//System.out.println(e);
	//ses.save(emp);
	tran.commit();

	}

}
