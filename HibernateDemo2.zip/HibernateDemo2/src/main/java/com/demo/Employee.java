package com.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="EmployeeDetails")
public class Employee {
@ Id
@Column(name="EMployeeID")
@GeneratedValue(strategy = GenerationType.AUTO)//to auto generate primary key values
	private int Emp_id;
@Column(name="EmployeeName",nullable =false,length = 30)
	private String Emp_Name;
@Column(name="EmployeeSalary")
	private float Emp_Salary;
	public int getEmp_id() {
		return Emp_id;
	}
	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}
	public String getEmp_Name() {
		return Emp_Name;
	}
	public void setEmp_Name(String emp_Name) {
		Emp_Name = emp_Name;
	}
	public float getEmp_Salary() {
		return Emp_Salary;
	}
	public void setEmp_Salary(float emp_Salary) {
		Emp_Salary = emp_Salary;
	}
	@Override
	public String toString() {
		return "Employee [Emp_id=" + Emp_id + ", Emp_Name=" + Emp_Name + ", Emp_Salary=" + Emp_Salary + "]";
	}

}
