package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) 
	{
		
		Configuration conf=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Address.class);
		ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
		SessionFactory sf=conf.buildSessionFactory(sr);
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();
		
		Address stu_add=new Address();
		stu_add.setCountry("Srilanka");
		stu_add.setState("Colombo");
		stu_add.setPincode(81116);
		stu_add.setStreet("Q street");
		//sess.save(stu_add);
		
		Student sob=new Student();
		sob.setName("Uday");
		sob.setsadd(stu_add);
		sess.save(sob);
		
		tran.commit();
		sess.close();
	}

}
