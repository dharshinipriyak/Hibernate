package com.edu;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="hibStudent")
public class Student 
{
@Id
@GeneratedValue
@Column(name="Stu_id",length=30)
private int id;

@Column(name="Stu_name",length=50)
private String name;

@Column(name="Stu_course",length=40)
private String course;
@OneToOne(cascade=CascadeType.ALL)
@JoinColumn(name="StudentAddress")
private Address sadd;

public Address getsadd() {
	return sadd;
}

public void setsadd(Address sadd) {
	this.sadd = sadd;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getCourse() {
	return course;
}

public void setCourse(String course) {
	this.course = course;
}

@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + ", course=" + course + "]";
}


}
