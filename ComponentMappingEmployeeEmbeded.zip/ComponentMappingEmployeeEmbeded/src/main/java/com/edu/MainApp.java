package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) {
	
		Configuration conf=new Configuration().configure().addAnnotatedClass(Employee.class);
		ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
		SessionFactory sf=conf.buildSessionFactory(sr);
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();
		
		Address addr=new Address("Munar","Kerala",768730);
		Employee emp=new Employee(104,"Dhilip",addr);
		
		sess.save(emp);
		tran.commit();
		sess.close();
	}

}
