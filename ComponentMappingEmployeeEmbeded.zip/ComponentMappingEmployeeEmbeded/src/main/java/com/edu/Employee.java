package com.edu;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EmployeeDetail")
public class Employee {

	@Id
	@Column(name="EmployeeId",length=10)
	private int eid;
	@Column(name="EmployeeName")
	private String ename;
	
	@Embedded
	private Address address;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", address=" + address + "]";
	}
	
public Employee() {
	super();
}

public Employee(int eid, String ename, Address address) {
	super();
	this.eid = eid;
	this.ename = ename;
	this.address = address;
}

}
