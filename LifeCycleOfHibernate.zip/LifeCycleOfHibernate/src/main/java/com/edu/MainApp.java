package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) {
	MyLaptopClass lob=new MyLaptopClass();
	//lob.setLid(12);
	lob.setLname("Dell");
	lob.setLprice(35000);//transient stage

	//hibernate leyer
	Configuration conf=new Configuration().configure().addAnnotatedClass(MyLaptopClass.class);
	ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
	SessionFactory sf=conf.buildSessionFactory(sr);
	Session sess=sf.openSession();
	
	//begin transaction
	Transaction tran=sess.beginTransaction();
	 //transient to persient stage
	//persient stage ->save record in database
	//java object converts row into database
	
	sess.save(lob);
	lob.setLprice(45000);
	tran.commit();
	
	
	//detach state
	/*sess.save(lob);
	tran.commit();
	sess.evict(lob);
	lob.setLprice(29000);
	*/
	
	//remove state
	sess.save(lob);
	//sess.delete(lob);
	tran.commit();
	
	}

}
