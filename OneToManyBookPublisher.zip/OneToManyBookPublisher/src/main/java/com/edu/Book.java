package com.edu;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="HibBook")
public class Book 
{
	@Id
private int bookid;
	@Column(length=40)
private String bookTitle;
	@Column(length=30)
private String AuthorName;
private double bookPrice;

public Book()
{
	super();
}
public Book(int bookid, String bookTitle, String AuthorName, double bookPrice) {
super();
this.bookid=bookid;
this.bookTitle=bookTitle;
this.AuthorName=AuthorName;
this.bookPrice=bookPrice;
}

public int getBookid() {
	return bookid;
}

public void setBookid(int bookid) {
	this.bookid = bookid;
}

public String getBookTitle() {
	return bookTitle;
}

public void setBookTitle(String bookTitle) {
	this.bookTitle = bookTitle;
}

public String getAuthorName() {
	return AuthorName;
}

public void setAuthorName(String authorName) {
	AuthorName = authorName;
}

public double getBookPrice() {
	return bookPrice;
}

public void setBookPrice(double bookPrice) {
	this.bookPrice = bookPrice;
}
@Override
public String toString() {
	return "Book [bookid=" + bookid + ", bookTitle=" + bookTitle + ", AuthorName=" + AuthorName + ", bookPrice="
			+ bookPrice + "]";
}

}
