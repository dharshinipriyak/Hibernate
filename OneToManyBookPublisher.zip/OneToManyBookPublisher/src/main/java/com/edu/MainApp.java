package com.edu;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) 
	{
		Configuration conf=new Configuration().configure().addAnnotatedClass(Book.class).addAnnotatedClass(Publisher.class);
		ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
		SessionFactory sf=conf.buildSessionFactory(sr);
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();
		Book book1=new Book(1,"Java in action","Kathy",700);
		Book book2=new Book(2,"API ","Johnson",600);
		Book book3=new Book(3,"Oracle ","John S",800);
	
		Set<Book>booklist=new HashSet<Book>(Arrays.asList(book1,book2,book3));
	
	Publisher publ=new Publisher();
	publ.setPub_id(10);
	publ.setPub_name("Tom");
	
	publ.setBooklist(booklist);
	
	sess.save(publ);
	//sess.save(publ1);
	tran.commit();
	sess.close();

	}

}
