package com.edu;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="HibPublisher")
public class Publisher
{
	@Id
private int Pub_id;
	
	@Column(length=30)
private String Pub_name;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="Pub_Book")
private Set<Book> booklist;

	public int getPub_id() {
		return Pub_id;
	}

	public void setPub_id(int pub_id) {
		Pub_id = pub_id;
	}

	public String getPub_name() {
		return Pub_name;
	}

	public void setPub_name(String pub_name) {
		Pub_name = pub_name;
	}

	public Set<Book> getBooklist() {
		return booklist;
	}

	public void setBooklist(Set<Book> booklist) {
		this.booklist = booklist;
	}

	@Override
	public String toString() {
		return "Publisher [Pub_id=" + Pub_id + ", Pub_name=" + Pub_name + ", booklist=" + booklist + "]";
	}

	
	
}
