package com.edu;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp {

	public static void main(String[] args) 
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu1");
	    EntityManager em=emf.createEntityManager();
	    
	  /* JpaStudent sob=em.find(JpaStudent.class,3);
	    System.out.println(sob);
	  */
	    
	    //insert
	    JpaStudent a=em.find(JpaStudent.class, 1);
	   System.out.println(a);
	    //insert
	    JpaStudent ob=new JpaStudent();
	    ob.setSid(4);
	    ob.setSname("Ravi");
	    ob.setScourse("Testing");
	    
	    em.getTransaction().begin();
	   
	    em.persist(ob);
	    System.out.println("After Insertion");
	   em.getTransaction().commit();
	   JpaStudent a1=em.find(JpaStudent.class, 2);
	   System.out.println(a1);

	

	}

}
