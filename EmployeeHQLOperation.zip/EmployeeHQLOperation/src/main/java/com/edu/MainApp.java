package com.edu;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) 
	{
		Configuration conf=new Configuration().configure().addAnnotatedClass(EmployeeHQL.class);
		ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
		SessionFactory sf=conf.buildSessionFactory(sr);
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();
		
		/*EmployeeHQL e1=new EmployeeHQL(1, "Ravi",25890,"Chennai",100);
		sess.save(e1);
		EmployeeHQL e2=new EmployeeHQL(2, "Pradeep",35320,"Bangalore",100);
		sess.save(e2);
		EmployeeHQL e3=new EmployeeHQL(3, "Deepak",23290.32f,"Munar",101);
		sess.save(e3);
		EmployeeHQL e4=new EmployeeHQL(4, "Uday",17333,"Pune",101);
		sess.save(e4);
		EmployeeHQL e5=new EmployeeHQL(5, "Gowtham",32681,"Hydrabad",102);
		sess.save(e5);*/
		//get record based on id
	/*EmployeeHQL r=(EmployeeHQL) sess.get(EmployeeHQL.class,1);
		System.out.println(r);
		*/
		
		//get data
		/*EmployeeHQL r=(EmployeeHQL) sess.get(EmployeeHQL.class,1);
		System.out.println("empid= "+r.getEid()+" Name= "+r.getEname()+" Salary = "+r.getSalary()+" Address = "+r.getAddress()+"DeptNo "+r.getDeptno());
		*/
		
		//retreive all record
		/*Query q=sess.createQuery(" from EmployeeHQL");
		List l=q.list();
		System.out.println(l);//by single line
		
		Iterator<EmployeeHQL> it=l.iterator();//by split
		while(it.hasNext())
		{
			EmployeeHQL r=it.next();
			System.out.println("empid= "+r.getEid()+" Name= "+r.getEname()+" Salary = "+r.getSalary()+" Address = "+r.getAddress()+"DeptNo "+r.getDeptno());
		
		}*/
		//update record
	
	/*Query q=sess.createQuery("update EmployeeHQL set salary=:s where eid=:i");
		q.setParameter("s", 4500f);
		q.setParameter("i", 4);
		int i=q.executeUpdate();
		if(i>0)
			{
			System.out.println("Record is updated");
			}
		else
		{
			System.out.println("record is not updated");
		}
		*/
	//delete the record
	
	/*Query q=sess.createQuery("delete from EmployeeHQL where eid=:i");
	q.setParameter("i",5);
	int i=q.executeUpdate();
	if(i>0)
		{
		System.out.println("Record is deleted");
		}
	else
	{
		System.out.println("record is not deleted");
	}
	*/
		//aggregate fnct
	//max,min,sum,avg
		Query mi=sess.createQuery("select min(salary) from EmployeeHQL");
		List l1=mi.list();
		System.out.println("Minimum Salary = "+l1.get(0));
		
		Query mx=sess.createQuery("select max(salary) from EmployeeHQL");
		List l2=mx.list();
		System.out.println("Maximum salary = "+l2.get(0));
		
		Query tot=sess.createQuery("select sum(salary) from EmployeeHQL");
		List l4=tot.list();
		System.out.println("Total salary = "+l4.get(0));
		
		Query av=sess.createQuery("select avg(salary) from EmployeeHQL");
		List l3=av.list();
		System.out.println("Average salary = "+l3.get(0));
		
		Query co=sess.createQuery("select count(*) from EmployeeHQL");
		List l5=co.list();
		System.out.println("Total Employee = "+l5.get(0));
		
		tran.commit();
		sess.close();
	}

}
