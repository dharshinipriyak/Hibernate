package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) {
	//laptop
		Laptop lob=new Laptop();
		lob.setLid(2);
		lob.setLname("Lenovo");
		lob.setLprice(23000);
		
		
		//student
		Student sob=new Student();
		sob.setRollno(11);
		sob.setName("Shali");
		sob.setMarks(477);
		sob.setLp(lob);
		
		Configuration conf=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Laptop.class);
		ServiceRegistry sr=new ServiceRegistryBuilder().applySettings(conf.getProperties()).buildServiceRegistry();
		SessionFactory sf=conf.buildSessionFactory(sr);
		Session sess=sf.openSession();
		
		//begin transaction
		Transaction tran=sess.beginTransaction();
		
		sess.save(lob);
		sess.save(sob);
		tran.commit();
		
	}

}
